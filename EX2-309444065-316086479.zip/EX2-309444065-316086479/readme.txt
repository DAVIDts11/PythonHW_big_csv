בס"ד

Solution to the 2-nd H.W. task.
submited by :
    Tsibulsky David 309444065 and Nahoom Chen 316086479


used libraries are :
    re , numpy , csv , time


running time is : 88.60 sec.  on  i7 .
   (88.60925507545471 - precise .)